<?php
/**
 * @author  wpWax
 * @since   6.6
 * @version 8.6
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$conditional_logic_attr = $searchform->get_conditional_logic_attributes( $data );
$selected_item          = $searchform::get_selected_category_option_data();
?>
<div class="directorist-search-field directorist-form-group <?php echo esc_attr( $empty_label ); ?>"<?php echo $conditional_logic_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Already escaped in get_conditional_logic_attributes() ?>>
    <div class="directorist-select directorist-search-category directorist-search-field__input">

        <?php if ( ! empty( $data['label'] ) ) : ?>
            <label class="directorist-search-field__label"><?php echo esc_attr( $data['label'] ); ?></label>
        <?php endif; ?>

        <select name="in_cat" class="<?php echo esc_attr( $searchform->category_class ); ?>" data-placeholder="<?php echo esc_attr( $data['placeholder'] ?? '' ); ?>" <?php echo ! empty( $data['required'] ) ? 'required="required"' : ''; ?> data-isSearch="true" data-selected-id="<?php echo esc_attr( $selected_item['id'] ); ?>" data-selected-label="<?php echo esc_attr( $selected_item['label'] ); ?>">
            <?php
                echo '<option value="">' . esc_html__( 'Category', 'directorist' ) . '</option>';

            if ( empty( $data['lazy_load'] ) ) {
                echo directorist_kses( $searchform->categories_fields, 'form_input' );
            }
            ?>
        </select>

    </div>
    <div class="directorist-search-field__btn directorist-search-field__btn--clear">
        <?php directorist_icon( 'fas fa-times-circle' ); ?> 
    </div>
</div>