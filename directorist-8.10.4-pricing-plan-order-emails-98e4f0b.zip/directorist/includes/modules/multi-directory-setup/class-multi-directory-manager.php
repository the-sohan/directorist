<?php

namespace Directorist\Multi_Directory;

class Multi_Directory_Manager {
    use Multi_Directory_Helper;

    public static $fields  = [];

    public static $layouts = [];

    public static $config  = [];

    public static $options = [];

    public static $migration  = null;

    public function __construct() {
        self::$migration = new Multi_Directory_Migration( [ 'multi_directory_manager' => $this ] );
    }

    // run
    public function run() {
        add_action( 'init', [$this, 'register_directory_taxonomy'] );
        add_action( 'init', [$this, 'setup_migration'] );

        if ( ! is_admin() ) {
            return;
        }

        add_filter( 'cptm_fields_before_update', [$this, 'cptm_fields_before_update'], 20, 1 );

        add_action( 'admin_menu', [$this, 'add_menu_pages'] );
        add_action( 'admin_post_delete_listing_type', [$this, 'handle_delete_listing_type_request'] );

        // Ajax
        add_action( 'wp_ajax_save_post_type_data', [ $this, 'save_post_type_data' ] );
        add_action( 'wp_ajax_save_imported_post_type_data', [ $this, 'save_imported_post_type_data' ] );
        add_action( 'wp_ajax_directorist_force_migrate', [ $this, 'handle_force_migration' ] );
    }

    public static function builder_data_backup( $term_id ) {
        $submission_form_fields     = get_term_meta( $term_id , 'submission_form_fields', true );
        $single_listings_contents   = get_term_meta( $term_id, 'single_listings_contents', true );
        $single_listing_header      = get_term_meta( $term_id, 'single_listing_header', true );

        // Fetch existing backup data from the option
        $existing_backup_data = get_option( 'directorist_builder_backup_data', [] );

        // Decode the JSON data if it exists
        $existing_backup_data = ! empty( $existing_backup_data ) ? json_decode( $existing_backup_data, true ) : [];

        if ( ! empty( $submission_form_fields ) && ! empty( $single_listings_contents ) && ! empty( $single_listing_header ) ) {
            $existing_backup_data[$term_id] = [
                'submission_form_fields'    => $submission_form_fields,
                'single_listings_contents'  => $single_listings_contents,
                'single_listing_header'     => $single_listing_header,
            ];
            // Convert the backup data to JSON format
            $json_backup_data = wp_json_encode( $existing_backup_data );

            // Save the JSON backup data in options
            update_option( 'directorist_builder_backup_data', $json_backup_data );
        }
    }

    // custom field assign to category migration
    public static function migrate_custom_field( $term_id ) {

        $submission_form_fields = get_term_meta( $term_id , 'submission_form_fields', true );
        // Deprecated: assign_to feature has been removed in favor of conditional_logic
        // This migration function is now a no-op
        if ( empty( $submission_form_fields['fields'] ) ) {
            return;
        }

        // Removed assign_to migration - use conditional_logic instead
        // Fields using assign_to should be migrated to use conditional_logic manually
    }

    public static function migrate_review_settings( $term_id ) {
        $old_review_settings = get_term_meta( $term_id, 'review_config', true );
        $new_review_builder  = get_term_meta( $term_id, 'single_listings_contents', true );

        // If no value is found, initialize the new review builder structure
        if ( empty( $new_review_builder ) ) {
            $new_review_builder = [
                'fields' => [],
                'groups' => [],
            ];
        }

        // Update review_cookies_consent in the 'groups' array if the review widget exists
        if ( ! empty( $old_review_settings['review_cookies_consent'] ) && is_array( $new_review_builder['groups'] ) ) {
            foreach ( $new_review_builder['groups'] as &$group ) {
                if ( isset( $group['widget_name'] ) && 'review' === $group['widget_name'] ) {
                    $group['review_cookies_consent'] = $old_review_settings['review_cookies_consent'];
                }
            }
        }

        // Mapping for fields outside of groups
        $fields_mapping = [
            'review_comment' => [
                'placeholder'       => 'review_comment_placeholder',
                'widget_name'       => 'review',
                'widget_child_name' => 'review_comment',
                'widget_key'        => 'review_comment',
                'widget_group'      => 'other_widgets',
            ],
            'review_email' => [
                'label'             => 'review_email_label',
                'placeholder'       => 'review_email_placeholder',
                'widget_name'       => 'review',
                'widget_child_name' => 'review_email',
                'widget_key'        => 'review_email',
                'widget_group'      => 'other_widgets',
            ],
            'review_name' => [
                'label'             => 'review_name_label',
                'placeholder'       => 'review_name_placeholder',
                'widget_name'       => 'review',
                'widget_child_name' => 'review_name',
                'widget_key'        => 'review_name',
                'widget_group'      => 'other_widgets',
            ],
            'review_website' => [
                'enable'            => 'review_show_website_field',
                'label'             => 'review_website_label',
                'placeholder'       => 'review_website_placeholder',
                'widget_name'       => 'review',
                'widget_child_name' => 'review_website',
                'widget_key'        => 'review_website',
                'widget_group'      => 'other_widgets',
            ],
        ];

        // Ensure the 'fields' key exists in the new_review_builder array
        if ( ! isset( $new_review_builder['fields'] ) || ! is_array( $new_review_builder['fields'] ) ) {
            $new_review_builder['fields'] = []; // Initialize if not present
        }

        // Add or update fields based on the mapping
        foreach ( $fields_mapping as $field_key => $mapping ) {
            if ( ! isset( $new_review_builder['fields'][ $field_key ] ) ) {
                $new_review_builder['fields'][ $field_key ] = []; // Initialize the field if it doesn't exist
            }

            // Add or update the mapped values
            foreach ( $mapping as $new_key => $old_key ) {
                if ( $new_key === 'widget_name' || $new_key === 'widget_child_name' || $new_key === 'widget_key' || $new_key === 'widget_group' ) {
                    // Directly assign widget-related keys
                    $new_review_builder['fields'][ $field_key ][ $new_key ] = $old_key;
                } else {
                    // Assign other keys if they exist in old_review_settings
                    if ( ! empty( $old_review_settings[ $old_key ] ) ) {
                        $new_review_builder['fields'][ $field_key ][ $new_key ] = $old_review_settings[ $old_key ];
                    }
                }
            }
        }

        // Ensure the 'groups' key exists in the new_review_builder array
        if ( ! isset( $new_review_builder['groups'] ) || ! is_array( $new_review_builder['groups'] ) ) {
            $new_review_builder['groups'] = []; // Initialize if not present
        }

        // Add or update groups with the 'review' widget
        foreach ( $new_review_builder['groups'] as &$group ) {
            if ( isset( $group['widget_name'] ) && 'review' === $group['widget_name'] ) {
                foreach ( array_keys( $fields_mapping ) as $field_key ) {
                    // Add the field to the group if it doesn't already exist
                    if ( ! in_array( $field_key, $group['fields'] ) ) {
                        $group['fields'][] = $field_key;
                    }
                }
            }
        }

        // Update the term meta with the modified new_review_builder array
        update_term_meta( $term_id, 'single_listings_contents', $new_review_builder );
    }

    public static function migrate_contact_owner_settings( $term_id ) {
        // Get the current settings
        $single_listings_contents = get_term_meta( $term_id, 'single_listings_contents', true );

        // Check if necessary fields exist
        if ( empty( $single_listings_contents['fields'] ) || empty( $single_listings_contents['groups'] ) || ! is_array( $single_listings_contents['groups'] ) ) {
            return;
        }

        // Define the fields mapping
        $fields_mapping = [
            'contact_name'    => [
                'enable'            => 1,
                'placeholder'       => __( 'Name', 'directorist' ),
                'widget_group'      => 'other_widgets',
                'widget_name'       => 'contact_listings_owner',
                'widget_child_name' => 'contact_name',
                'widget_key'        => 'contact_name',
            ],
            'contact_email'   => [
                'placeholder'       => __( 'Email', 'directorist' ),
                'widget_group'      => 'other_widgets',
                'widget_name'       => 'contact_listings_owner',
                'widget_child_name' => 'contact_email',
                'widget_key'        => 'contact_email',
            ],
            'contact_message' => [
                'placeholder'       => __( 'Message...', 'directorist' ),
                'widget_group'      => 'other_widgets',
                'widget_name'       => 'contact_listings_owner',
                'widget_child_name' => 'contact_message',
                'widget_key'        => 'contact_message',
            ],
        ];

        // Iterate over groups and update the contact listings owner group
        foreach ( $single_listings_contents['groups'] as &$group ) {
            if ( isset( $group['widget_name'] ) && 'contact_listings_owner' === $group['widget_name'] ) {
                foreach ( $fields_mapping as $field_key => $mapping ) {
                    // Add or update fields
                    $single_listings_contents['fields'][ $field_key ] = $mapping;

                    // Ensure the field is added to the group's fields
                    if ( ! in_array( $field_key, $group['fields'], true ) ) {
                        $group['fields'][] = $field_key;
                    }
                }
            }
        }

        // Update the term meta with the modified contents
        update_term_meta( $term_id, 'single_listings_contents', $single_listings_contents );
    }

    public static function migrate_related_listing_settings( $term_id ) {
        $number              = get_term_meta( $term_id, 'similar_listings_number_of_listings_to_show', true );
        $same_author         = get_term_meta( $term_id, 'listing_from_same_author', true );
        $logic               = get_term_meta( $term_id, 'similar_listings_logics', true );
        $column              = get_term_meta( $term_id, 'similar_listings_number_of_columns', true );
        $new_related_listing = get_term_meta( $term_id, 'single_listings_contents', true );

        if ( ! empty( $new_related_listing['groups'] ) && is_array( $new_related_listing['groups'] ) ) {
            foreach ( $new_related_listing['groups'] as &$group ) {
                if ( isset( $group['widget_name'] ) && 'related_listings' === $group['widget_name'] ) {
                    $group['similar_listings_logics']                     = $logic ?? 'OR';
                    $group['listing_from_same_author']                    = $same_author ?? false;
                    $group['similar_listings_number_of_listings_to_show'] = absint( $number ?? 3 );
                    $group['similar_listings_number_of_columns']          = absint( $column ?? 3 );
                }
            }
        }

        update_term_meta( $term_id, 'single_listings_contents', $new_related_listing );
    }

    public static function migrate_privacy_policy( $term_id ) {
        $display_privacy     = (bool) get_directorist_type_option( $term_id, 'listing_privacy' );
        $privacy_is_required = (bool) get_directorist_type_option( $term_id, 'privacy_is_required' );
        $display_terms       = (bool) get_directorist_type_option( $term_id, 'listing_terms_condition' );
        $terms_is_required   = (bool) get_directorist_type_option( $term_id, 'require_terms_conditions' );
        $submission_form     = get_term_meta( $term_id, 'submission_form_fields', true );

        // Generate the label with links to Privacy Policy and Terms of Service
        $terms_privacy_label = sprintf(
            __( 'I agree to the <a href="%s" target="_blank">Privacy Policy</a> and <a href="%s" target="_blank">Terms of Service</a>', 'directorist' ),
            \ATBDP_Permalink::get_privacy_policy_page_url(),
            \ATBDP_Permalink::get_terms_and_conditions_page_url()
        );

        // Determine if the field should be required
        $is_required = ( $privacy_is_required || $terms_is_required ) ? 1 : '';

        // Define the new field for terms and privacy
        $terms_privacy_field = [
            'type'         => 'text',
            'field_key'    => 'privacy_policy',
            'text'         => $terms_privacy_label,   // Use the generated label
            'required'     => $is_required,           // Dynamically set required status
            'widget_group' => 'preset',
            'widget_name'  => 'terms_privacy',
            'widget_key'   => 'terms_privacy',
        ];

        // Check if either privacy or terms should be displayed
        if ( $display_privacy || $display_terms ) {
            // Add the new field to the fields array
            $submission_form['fields']['terms_privacy'] = $terms_privacy_field;
            // Add the 'terms_privacy' field to the last group in the 'groups' array
            $last_group_key = array_key_last( $submission_form['groups'] ); // Get the last group key
            $submission_form['groups'][ $last_group_key ]['fields'][] = 'terms_privacy'; // Add to the last group's fields
        }

        // Update the term meta with the modified submission_form array
        update_term_meta( $term_id, 'submission_form_fields', $submission_form );
    }

    // add_missing_single_listing_section_id
    public function add_missing_single_listing_section_id() {
        $directory_types = directorist_get_directories();

        if ( is_wp_error( $directory_types ) || empty( $directory_types ) ) {
            return;
        }

        foreach ( $directory_types as $directory_type ) {
            $single_listings_contents = get_term_meta( $directory_type->term_id, 'single_listings_contents', true );
            $need_to_update = false;

            if ( empty( $single_listings_contents ) ) {
                continue;
            }

            if ( empty( $single_listings_contents['groups'] ) ) {
                continue;
            }

            foreach ( $single_listings_contents['groups'] as $group_index => $group ) {
                $has_section_id = ( ! empty( $group['section_id'] ) ) ? true : false;
                $renew = ( $has_section_id ) ? false : true;
                $renew = apply_filters( 'directorist_renew_single_listing_section_id', $renew );

                if ( ! $renew ) {
                    continue;
                }

                $group['section_id'] = $group_index + 1;
                $single_listings_contents['groups'][ $group_index ] = $group;
                $need_to_update = true;
            }

            if ( $need_to_update ) {
                update_term_meta( $directory_type->term_id, 'single_listings_contents', $single_listings_contents );
            }
        }
    }

    // update_default_directory_type_option
    public function update_default_directory_type_option() {
        $args = [
            'meta_query' => [
                [
                    'key'   => '_default',
                    'value' => true,
                ]
            ],
        ];

        $default_directory = get_directorist_option( 'atbdp_default_derectory', '' );
        $terms = directorist_get_directories( $args );

        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
            $default_directory = $terms[0]->term_id;
        }

        update_directorist_option( 'atbdp_default_derectory', $default_directory );
    }

    // setup_migration
    public function setup_migration() {
        $migrated = get_option( 'atbdp_migrated', false );
        $need_migration = ( empty( $migrated ) && ! self::has_multidirectory() && self::has_old_listings_data() ) ? true : false;

        if ( $need_migration ) {
            $this->prepare_settings();
            self::$migration->migrate();
            return;
        }

        $need_import_default = ( ! self::has_multidirectory() ) ? true : false;

        if ( apply_filters( 'atbdp_import_default_directory', $need_import_default ) ) {
            $this->prepare_settings();
            $this->import_default_directory();
        }
    }

    // has_multidirectory
    public static function has_multidirectory() {
        $directory_types = directorist_get_directories();

        return ( ! is_wp_error( $directory_types ) && ! empty( $directory_types ) ) ? true : false;
    }

    // has_old_listings_data
    public static function has_old_listings_data() {
        $get_listings = new \WP_Query(
            [
                'post_type'      => ATBDP_POST_TYPE,
                'posts_per_page' => 1,
                'fields'         => 'ids',
            ]
        );

        $get_custom_fields = new \WP_Query(
            [
                'post_type'      => ATBDP_CUSTOM_FIELD_POST_TYPE,
                'posts_per_page' => 1,
                'fields'         => 'ids',
            ]
        );

        $has_listings          = $get_listings->post_count;
        $has_custom_fields     = $get_custom_fields->post_count;

        return ( $has_listings || $has_custom_fields ) ? true : false;
    }

    // handle_force_migration
    public function handle_force_migration() {
        if ( ! directorist_verify_nonce() ) {
            wp_send_json(
                [
                    'status' => [
                        'success' => false,
                        'message' => __( 'Something is wrong! Please refresh and retry.', 'directorist' ),
                    ],
                ], 200
            );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json(
                [
                    'status' => [
                        'success' => false,
                        'message' => __( 'You are not allowed to access this resource', 'directorist' ),
                    ],
                ], 200
            );
        }

        wp_send_json( $this->run_force_migration() );
    }

    // run_force_migration
    public function run_force_migration() {
        $general_directory = term_exists( 'General', 'atbdp_listing_types' );
        $args = [];

        if ( $general_directory ) {
            $args[ 'term_id' ] = $general_directory['term_id'];
        }

        $this->prepare_settings();
        $migration_status = self::$migration->migrate( $args );

        $status = [
            'success' => $migration_status['success'],
            'message' => ( $migration_status ) ? __( 'Migration Successful', 'directorist' ) : __( 'Migration Failed', 'directorist' ),
        ];

        return $status;
    }

    // import_default_directory
    public function import_default_directory( array $args = [] ) {
        $file = DIRECTORIST_ASSETS_DIR . 'sample-data/directory/directory.json';
        if ( ! file_exists( $file ) ) {
            return; }
        $file_contents = file_get_contents( $file );

        $add_directory = self::add_directory(
            [
                'directory_name' => 'General',
                'fields_value'   => $file_contents,
                'is_json'        => true
            ]
        );

        if ( $add_directory['status']['success'] ) {
            update_option( 'atbdp_has_multidirectory', true );
            update_term_meta( $add_directory['term_id'], '_default', true );

            // Add directory type to all listings
            $listings = new \WP_Query(
                [
                    'post_type' => ATBDP_POST_TYPE,
                    'status'    => 'publish',
                    'per_page'  => -1,
                ]
            );

            if ( $listings->have_posts() ) {
                while ( $listings->have_posts() ) {
                    $listings->the_post();

                    wp_set_object_terms( get_the_id(), $add_directory['term_id'], 'atbdp_listing_types' );
                }
                wp_reset_postdata();
            }
        }
    }

    public function save_imported_post_type_data() {

        if ( ! directorist_verify_nonce() ) {
            wp_send_json(
                [
                    'status' => [
                        'success' => false,
                        'status_log' => [
                            'nonce_is_missing' => [
                                'type' => 'error',
                                'message' => __( 'Something is wrong! Please refresh and retry.', 'directorist' ),
                            ],
                        ],
                    ],
                ], 200
            );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json(
                [
                    'status' => [
                        'success' => false,
                        'status_log' => [
                            'access_denied' => [
                                'type' => 'error',
                                'message' => __( 'You are not allowed to access this resource', 'directorist' ),
                            ],
                        ],
                    ],
                ], 200
            );
        }

        $term_id        = ( ! empty( $_POST[ 'term_id' ] ) ) ? absint( $_POST[ 'term_id' ] ) : 0;
        $directory_name = ( ! empty( $_POST[ 'directory-name' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'directory-name' ] ) ) : '';
        $json_file      = ( ! empty( $_FILES[ 'directory-import-file' ] ) ) ? directorist_clean( $_FILES[ 'directory-import-file' ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Unslashing corrupts Windows upload paths in raw $_FILES data.

        // Validation
        $response = [
            'status' => [
                'success'     => true,
                'status_log'  => [],
                'error_count' => 0,
            ]
        ];

        // Validate file
        if ( empty( $json_file ) ) {
            $response['status']['status_log']['file_is_missing'] = [
                'type' => 'error',
                'message' => __( 'File is missing', 'directorist' ),
            ];

            $response['status']['error_count']++;
        }

        // Validate file data
        $file_contents = file_get_contents( $json_file['tmp_name'] );
        if ( empty( $file_contents ) ) {
            $response['status']['status_log']['invalid_data'] = [
                'type' => 'error',
                'message' => __( 'The data is invalid', 'directorist' ),
            ];

            $response['status']['error_count']++;
        }

        // Send respone if has error
        if ( $response['status']['error_count'] ) {
            $response['status']['success'] = false;
            wp_send_json( $response , 200 );
        }

        // If dierctory name is numeric update the term instead of creating
        if ( is_numeric( $directory_name ) ) {
            $term_id = (int) $directory_name;
            $directory_name = '';
        }

        $this->prepare_settings();

        $add_directory = self::add_directory(
            [
                'term_id'        => $term_id,
                'directory_name' => $directory_name,
                'fields_value'   => $file_contents,
                'is_json'        => true
            ]
        );

        wp_send_json( $add_directory, 200 );
    }

    // cptm_fields_before_update
    public function cptm_fields_before_update( $fields ) {
        $new_fields     = $fields;
        $fields_group   = self::$config['fields_group'];

        foreach ( $fields_group as $group_name => $group_fields ) {
            $grouped_fields_value = [];

            foreach ( $group_fields as $field_index => $field_key ) {
                if ( is_string( $field_key ) && array_key_exists( $field_key, self::$fields ) ) {
                    $grouped_fields_value[ $field_key ] = ( isset( $new_fields[ $field_key ] ) ) ? $new_fields[ $field_key ] : '';
                    unset( $new_fields[ $field_key ] );
                }

                if ( is_array( $field_key ) ) {
                    $grouped_fields_value[ $field_index ] = [];

                    foreach ( $field_key as $sub_field_key ) {
                        if ( array_key_exists( $sub_field_key, self::$fields ) ) {
                            $grouped_fields_value[ $field_index ][ $sub_field_key ] = ( isset( $new_fields[ $sub_field_key ] ) ) ? $new_fields[ $sub_field_key ] : '';
                            unset( $new_fields[ $sub_field_key ] );
                        }
                    }
                }
            }

            $new_fields[ $group_name ] = $grouped_fields_value;
        }

        return $new_fields;
    }

    // save_post_type_data
    public function save_post_type_data() {
        if ( ! directorist_verify_nonce() ) {
            wp_send_json(
                [
                    'status' => [
                        'success' => false,
                        'status_log' => [
                            'nonce_is_missing' => [
                                'type' => 'error',
                                'message' => __( 'Something is wrong! Please refresh and retry.', 'directorist' ),
                            ],
                        ],
                    ],
                ], 200
            );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json(
                [
                    'status' => [
                        'success' => false,
                        'status_log' => [
                            'access_denied' => [
                                'type' => 'error',
                                'message' => __( 'You are not allowed to access this resource', 'directorist' ),
                            ],
                        ],
                    ],
                ], 200
            );
        }

        if ( empty( $_POST['name'] ) ) {
            wp_send_json(
                [
                    'status' => [
                        'success' => false,
                        'status_log' => [
                            'name_is_missing' => [
                                'type' => 'error',
                                'message' => __( 'Name is missing', 'directorist' ),
                            ],
                        ],
                    ],
                ], 200
            );
        }

        $term_id        = ( ! empty( $_POST['listing_type_id'] ) ) ? absint( $_POST['listing_type_id'] ) : 0;
        $directory_name = sanitize_text_field( wp_unslash( $_POST['name'] ) );

        $fields     = [];
        $field_list = ! empty( $_POST['field_list'] ) ? directorist_maybe_json( wp_unslash( $_POST['field_list'] ) ) : [];

        foreach ( $field_list as $field_key ) {
            if ( isset( $_POST[$field_key] ) && 'name' !==  $field_key ) {
                $fields[ $field_key ] = directorist_maybe_json(
                    wp_unslash( $_POST[ $field_key ] ),
                    true,
                    'directorist_clean_post'
                );
            }
        }

        /**
         * @since 7.7.0
         * It fires before directory data updated
         */

         do_action( 'directorist_before_directory_type_updated' );

        $this->prepare_settings();

        $add_directory = self::add_directory(
            [
                'term_id'        => $term_id,
                'directory_name' => $directory_name,
                'fields_value'   => $fields,
            ]
        );

        if ( ! $add_directory['status']['success'] ) {
            wp_send_json( $add_directory );
        }

        if ( directorist_is_multi_directory_enabled() && empty( $term_id ) ) {
            $redirect_url = admin_url( 'edit.php?post_type=at_biz_dir&page=atbdp-directory-types&action=edit&listing_type_id=' . $add_directory['term_id'] );
            $add_directory['redirect_url'] = $redirect_url;
        }

        wp_send_json( $add_directory );
    }

    // update_validated_term_meta
    public static function update_validated_term_meta( $term_id, $field_key, $value ) {
        if ( ! isset( self::$fields[$field_key] ) && ! array_key_exists( $field_key, self::$config['fields_group'] ) ) {
            return;
        }

        if ( ! empty( self::$fields[$field_key]['type'] ) && 'toggle' === self::$fields[$field_key]['type'] ) {
            $value = ( 'true' === $value || true === $value || '1' === $value || 1 === $value ) ? true : 0;
        }

        $value = directorist_maybe_json( $value, false, 'directorist_clean_post' );

        update_term_meta( $term_id, $field_key, $value );
    }

    public function prepare_settings() {
        static::load_builder_data();
    }

    public static function load_builder_data() {
        if ( empty( self::$fields ) ) {
            $builder_data = new Builder_Data();

            self::$fields  = $builder_data->get_fields();
            self::$layouts = $builder_data->get_layouts();
            self::$config  = $builder_data->get_config();
            self::$options = $builder_data->get_options();
        }
    }

    // add_menu_pages
    public function add_menu_pages() {
        $page_title              = __( 'Directory Builder', 'directorist' );
        $page_slug               = $this->get_active_directory_builder_page_slug();
        $compatibility_page_slug = ( 'atbdp-directory-types' === $page_slug ) ? 'atbdp-layout-builder' : 'atbdp-directory-types';

        add_submenu_page(
            'edit.php?post_type=at_biz_dir',
            $page_title,
            $page_title,
            'manage_options',
            $page_slug,
            [$this, 'menu_page_callback__directory_types'],
            5
        );

        $compatibility_page_hook = add_submenu_page(
            '',
            $page_title,
            $page_title,
            'manage_options',
            $compatibility_page_slug,
            [$this, 'redirect_to_active_directory_builder_page']
        );

        if ( $compatibility_page_hook ) {
            add_action( "load-{$compatibility_page_hook}", [$this, 'redirect_to_active_directory_builder_page'] );
        }
    }

    /**
     * Get the directory builder page slug for the current multi-directory mode.
     *
     * @return string
     */
    private function get_active_directory_builder_page_slug() {
        return directorist_is_multi_directory_enabled() ? 'atbdp-directory-types' : 'atbdp-layout-builder';
    }

    /**
     * Redirect the inactive directory builder route to the active route.
     *
     * This keeps stale admin-menu links and saved bookmarks working after the
     * multi-directory setting is changed through the AJAX settings form.
     *
     * @return void
     */
    public function redirect_to_active_directory_builder_page() {
        $redirect_url = add_query_arg(
            [
                'post_type' => 'at_biz_dir',
                'page'      => $this->get_active_directory_builder_page_slug(),
            ],
            admin_url( 'edit.php' )
        );

        wp_safe_redirect( $redirect_url );
        exit;
    }

    // get_default_directory_id
    public function get_default_directory_id() {
        $default_directory = get_directorist_option( 'atbdp_default_derectory', '' );

        if ( ! empty( $default_directory ) ) {
            return $default_directory;
        }

        return 0;
    }

    // menu_page_callback__directory_types
    public function menu_page_callback__directory_types() {
        $enable_multi_directory = directorist_is_multi_directory_enabled();

        $action = isset( $_GET['action'] ) ? sanitize_text_field( wp_unslash( $_GET['action'] ) ) : '';
        $listing_type_id = 0;

        $data = [
            'add_new_link' => admin_url( 'edit.php?post_type=at_biz_dir&page=atbdp-directory-types&action=add_new' ),
        ];

        if ( ! $enable_multi_directory || ( ! empty( $action ) && ( 'edit' === $action || 'add_new' === $action ) ) ) {
            $this->prepare_settings();
            $this->add_missing_single_listing_section_id();

            $listing_type_id = ( ! empty( $_REQUEST['listing_type_id'] ) ) ? absint( $_REQUEST['listing_type_id'] ) : 0;
            $listing_type_id = ( ! $enable_multi_directory ) ? default_directory_type() : $listing_type_id;

            $this->update_fields_with_old_data( $listing_type_id );

            $directory_builder_data = [
                'fields'  => self::$fields,
                'layouts' => self::$layouts,
                'config'  => self::$config,
                'options' => self::$options,
                'id'      => $listing_type_id,
            ];

            /**
             * Filter directory builder's all configuration data.
             *
             * @since 7.0.5.*
             * TODO: Update with exact version number.
             */
            $directory_builder_data = apply_filters( 'directorist_builder_localize_data', $directory_builder_data );

            $data[ 'directory_builder_data' ] = $directory_builder_data;

            atbdp_load_admin_template( 'post-types-manager/edit-listing-type', $data );
            return;
        }

        atbdp_load_admin_template( 'post-types-manager/all-listing-types', $data );
    }

    public function update_fields_with_old_data( $listing_type_id = 0 ) {
        $term = get_term( $listing_type_id, 'atbdp_listing_types' );

        if ( is_wp_error( $term ) || empty( $term ) ) {
            return;
        }

        $term_name = ( $term ) ? $term->name : '';
        $term_id   = ( $term ) ? $term->term_id : 0;

        self::$options['name']['value'] = $term_name;

        $all_term_meta = get_term_meta( $term_id );
        $test_migration = apply_filters( 'atbdp_test_migration', false );

        if ( $test_migration ) {
            $all_term_meta = self::$migration->get_fields_data();
        }

        if ( ! is_array( $all_term_meta ) ) {
            return;
        }

        foreach ( $all_term_meta as $meta_key => $meta_value ) {
            if ( isset( self::$fields[$meta_key] ) ) {
                $_meta_value = ( ! $test_migration ) ? $meta_value[0] : $meta_value;
                $value = maybe_unserialize( maybe_unserialize( $_meta_value ) );

                self::$fields[ $meta_key ]['value'] = $value;
            }
        }

        // Merge new layout placeholders into saved card-builder field values.
        // When a new placeholder (e.g. action-placeholder) is added to the default
        // layout but the directory was saved before it existed, this ensures the
        // placeholder appears in the builder UI for existing directory types.
        $this->merge_new_layout_placeholders_into_saved_value( 'single_listing_header' );
        $this->merge_new_card_layout_sections_into_saved_value( 'listings_card_grid_view' );
        $this->merge_new_card_layout_sections_into_saved_value( 'listings_card_list_view' );

        foreach ( self::$config['fields_group'] as $group_key => $group_fields ) {
            if ( array_key_exists( $group_key, $all_term_meta ) ) {
                $_group_meta_value = ( ! $test_migration ) ? $all_term_meta[$group_key][0] : $all_term_meta[$group_key];
                $group_value = maybe_unserialize( maybe_unserialize( $_group_meta_value ) );

                foreach ( $group_fields as $field_index => $field_key ) {

                    if ( ! key_exists( $field_key, $group_value ) ) {
                        continue; }

                    if ( is_string( $field_key ) && array_key_exists( $field_key, self::$fields ) ) {
                        self::$fields[$field_key]['value'] = $group_value[$field_key];
                    }

                    if ( is_array( $field_key ) ) {
                        foreach ( $field_key as $sub_field_key ) {
                            if ( array_key_exists( $sub_field_key, self::$fields ) ) {
                                self::$fields[$sub_field_key]['value'] = $group_value[$field_index][$sub_field_key];
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Merge new layout placeholders into saved card-builder field values.
     *
     * When a new placeholder is added to the default layout definition but the
     * directory type was saved before that placeholder existed, the saved value
     * (from term meta) won't contain it. This method detects the gap and injects
     * the missing placeholder(s) at the correct position so the builder UI
     * shows them without requiring a manual reset.
     *
     * @param string $field_key The field key (e.g. 'single_listing_header').
     */
    protected function merge_new_layout_placeholders_into_saved_value( $field_key ) {
        // Sanitize input for security.
        $field_key = sanitize_key( $field_key );

        if ( ! isset( self::$fields[ $field_key ] ) ) {
            return;
        }

        $field  = self::$fields[ $field_key ];
        $value  = isset( $field['value'] ) ? $field['value'] : null;
        $layout = isset( $field['layout'] ) ? $field['layout'] : null;

        if ( ! is_array( $value ) || ! is_array( $layout ) ) {
            return;
        }

        // Collect all placeholder keys already present in the saved value.
        // Use associative array for O(1) lookup instead of O(n) in_array().
        $saved_keys = [];
        $collect_keys = function ( $items ) use ( &$saved_keys, &$collect_keys ) {
            foreach ( $items as $item ) {
                if ( isset( $item['placeholderKey'] ) ) {
                    $saved_keys[ $item['placeholderKey'] ] = true;
                }
                if ( isset( $item['placeholders'] ) && is_array( $item['placeholders'] ) ) {
                    $collect_keys( $item['placeholders'] );
                }
            }
        };
        $collect_keys( $value );

        // Walk the default layout and inject any missing placeholders.
        $offset = 0;
        foreach ( $layout as $index => $layout_item ) {
            if ( ! isset( $layout_item['placeholderKey'] ) ) {
                continue;
            }

            // Use isset for O(1) lookup instead of in_array() O(n).
            if ( isset( $saved_keys[ $layout_item['placeholderKey'] ] ) ) {
                continue;
            }

            // Placeholder exists in default layout but not in saved value — inject it.
            $insert_position = min( $index + $offset, count( $value ) );
            array_splice( $value, $insert_position, 0, [ $layout_item ] );
            $offset++;
        }

        if ( $offset > 0 ) {
            self::$fields[ $field_key ]['value'] = $value;
        }
    }

    /**
     * Merge new layout sections into saved card-builder field values.
     *
     * When a new section (e.g. action) is added to the default card layout but the
     * directory type was saved before it existed, the saved value won't contain it.
     * This method detects missing sections and adds them from the default layout.
     *
     * @param string $field_key The field key (e.g. 'listings_card_grid_view').
     */
    protected function merge_new_card_layout_sections_into_saved_value( $field_key ) {
        // Sanitize input for security.
        $field_key = sanitize_key( $field_key );

        if ( ! isset( self::$fields[ $field_key ] ) ) {
            return;
        }

        $field          = self::$fields[ $field_key ];
        $value          = isset( $field['value'] ) ? $field['value'] : null;
        $card_templates = isset( $field['card_templates'] ) ? $field['card_templates'] : null;

        if ( ! is_array( $value ) || ! is_array( $card_templates ) ) {
            return;
        }

        $has_changes     = false;
        $section_types   = [ 'body', 'thumbnail', 'footer' ];

        // Process each template (grid_view_with_thumbnail, grid_view_without_thumbnail, etc.)
        foreach ( $card_templates as $template_key => $template_config ) {
            if ( ! isset( $template_config['layout'] ) || ! is_array( $template_config['layout'] ) ) {
                continue;
            }

            $default_layout = $template_config['layout'];

            if ( ! isset( $value['template_data'][ $template_key ] ) || ! is_array( $value['template_data'][ $template_key ] ) ) {
                continue;
            }

            $saved_template_data = &$value['template_data'][ $template_key ];
            $template_has_changes = false;

            // Process all section types (body, thumbnail, footer) using the same logic
            foreach ( $section_types as $section_type ) {
                if ( ! isset( $default_layout[ $section_type ] ) || ! is_array( $default_layout[ $section_type ] ) ) {
                    continue;
                }

                if ( ! isset( $saved_template_data[ $section_type ] ) ) {
                    $saved_template_data[ $section_type ] = [];
                    $template_has_changes                 = true;
                }

                foreach ( $default_layout[ $section_type ] as $section_key => $section_config ) {
                    if ( ! isset( $saved_template_data[ $section_type ][ $section_key ] ) ) {
                        // Section exists in default but not in saved value — add it.
                        $saved_template_data[ $section_type ][ $section_key ] = [];
                        $template_has_changes                                 = true;
                    }
                }
            }

            if ( $template_has_changes ) {
                $has_changes = true;
            }
        }

        if ( $has_changes ) {
            self::$fields[ $field_key ]['value'] = $value;
        }
    }

    // handle_delete_listing_type_request
    public function handle_delete_listing_type_request() {
        if ( ! directorist_verify_nonce( '_wpnonce', 'delete_listing_type' ) ) {
            wp_die( esc_html__( 'Invalid request', 'directorist' ) );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to delete directory type', 'directorist' ) );
        }

        $term_id = isset( $_REQUEST['listing_type_id'] ) ? absint( $_REQUEST['listing_type_id'] ) : 0;

        $this->delete_listing_type( $term_id );

        wp_redirect( admin_url( 'edit.php?post_type=at_biz_dir&page=atbdp-directory-types' ) );
        exit;
    }

    // delete_listing_type
    public function delete_listing_type( $term_id = 0 ) {
        if ( wp_delete_term( $term_id, 'atbdp_listing_types' ) ) {
            atbdp_add_flush_alert(
                [
                    'id'      => 'deleting_listing_type_status',
                    'page'    => 'all-listing-type',
                    'message' => __( 'Successfully Deleted the listing type', 'directorist' ),
                ]
            );
        } else {
            atbdp_add_flush_alert(
                [
                    'id'      => 'deleting_listing_type_status',
                    'page'    => 'all-listing-type',
                    'type'    => 'error',
                    'message' => __( 'Failed to delete the listing type', 'directorist' )
                ]
            );
        }
    }

    // register_directory_taxonomy
    public function register_directory_taxonomy() {
        register_taxonomy(
            ATBDP_DIRECTORY_TYPE, [ ATBDP_POST_TYPE ], apply_filters(
                'directorist_register_directory_taxonomy_args',  [
                    'hierarchical' => false,
                    'labels'       => [
                        'name'          => _x( 'Listing Directory', 'taxonomy general name', 'directorist' ),
                        'singular_name' => _x( 'Listing Directory', 'taxonomy singular name', 'directorist' ),
                        'search_items'  => __( 'Search listing directory', 'directorist' ),
                        'menu_name'     => __( 'Listing Directory', 'directorist' ),
                    ],
                    'show_ui'      => false,
                ] 
            ) 
        );
    }

    /**
     * Get all the pages in an array where each page is an array of key:value:id and key:label:name
     *
     * Example : array(
     *                  array('value'=> 1, 'label'=> 'page_name'),
     *                  array('value'=> 50, 'label'=> 'page_name'),
     *          )
     * @return array page names with key value pairs in a multi-dimensional array
     * @since 3.0.0
     */
    public function get_pages_vl_arrays() {
        $pages = get_pages();
        $pages_options = [];
        if ( $pages ) {
            foreach ( $pages as $page ) {
                $pages_options[] = ['value' => $page->ID, 'label' => $page->post_title];
            }
        }

        return $pages_options;
    }
}
